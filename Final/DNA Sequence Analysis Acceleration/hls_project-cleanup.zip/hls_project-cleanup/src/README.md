# Source Files

## Build Software Implementation
```
make
```

## Run
```
./align ../data/1.fasta.fmi ../data/1.fastq
```
