# Where is the test data from?
We gained access to the WK2000 test case from https://github.com/hariby/SA-complete-graph/releases.<br>
New test cases can be generated from the WK2000 case by running `genCase.py` in `WK2000` folder and specify the desired vertex number.<br>

# What is WK2000?
WK2000 is a test case for weighted max-cut problem of a 2000-vertex complete graph.
![](https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Max-cut.svg/1200px-Max-cut.svg.png)
