#ifndef _PRNG_HPP_
#define _PRNG_HPP_

#include "sqa.hpp"

/* Pseudo Random Number Generator */
fp_t uniform01(int &seed);

#endif