| nTrot | Gamma | maxTemp | minTemp | iter  | solved iter |
| ----- | ----- | ------- | ------- | ----- | ----------- |
| 2     | 0.001 | 0.4     | 0.2     | 10000 | 4038        |
