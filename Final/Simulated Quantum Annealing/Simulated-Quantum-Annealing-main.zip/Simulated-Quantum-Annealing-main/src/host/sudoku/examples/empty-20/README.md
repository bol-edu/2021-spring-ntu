| nTrot | Gamma | maxTemp | minTemp | iter   | solved iter |
| ----- | ----- | ------- | ------- | ------ | ----------- |
| 2     | 1e-8  | 0.25    | 0.1     | 100000 | 91700       |
