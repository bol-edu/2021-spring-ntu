// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2020.1 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_compute_matrices (
ap_uint<64>* string1_g,
ap_uint<64>* string2_g,
ap_uint<64>* direction_matrix_g);
