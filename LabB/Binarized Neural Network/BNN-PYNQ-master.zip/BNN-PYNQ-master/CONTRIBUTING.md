We welcome contributions to BNN-PYNQ.  Please first sign our <a href="https://www.clahub.com/agreements/Xilinx/BNN-PYNQ"> Contributor License Agreement</a>.
