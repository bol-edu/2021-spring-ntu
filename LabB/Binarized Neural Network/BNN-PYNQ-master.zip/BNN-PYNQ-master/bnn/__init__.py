from .bnn import PynqBNN, CnvClassifier, LfcClassifier, RUNTIME_HW, RUNTIME_SW
from .bnn import NETWORK_CNVW1A1, NETWORK_CNVW1A2, NETWORK_CNVW2A2, NETWORK_LFCW1A1, NETWORK_LFCW1A2, available_params

__version__ = 0.1
